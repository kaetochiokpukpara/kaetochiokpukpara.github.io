package com.zybooks.cs360_project_kaetochiokpukpara;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 2;

    // users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // daily weight table
    private static final String TABLE_DAILY_WEIGHT = "daily_weights";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // goal weight table
    private static final String TABLE_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_GOAL_WEIGHT = "goal";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_DAILY_WEIGHT_TABLE = "CREATE TABLE " + TABLE_DAILY_WEIGHT + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT UNIQUE, " +
                COLUMN_WEIGHT + " REAL)";
        db.execSQL(CREATE_DAILY_WEIGHT_TABLE);

        String CREATE_GOAL_WEIGHT_TABLE = "CREATE TABLE " + TABLE_GOAL_WEIGHT + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_GOAL_WEIGHT + " REAL)";
        db.execSQL(CREATE_GOAL_WEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);
        onCreate(db);
    }

    // check if user exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }

    // validate username and password
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{username, password});
        boolean isValid = cursor.moveToFirst();
        cursor.close();
        db.close();
        return isValid;
    }

    // add a new user
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    // add a daily weight
    public void addDailyWeight(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        // replace() is used so there is only one weight per date
        db.replace(TABLE_DAILY_WEIGHT, null, values);
        db.close();
    }

    // edit a daily weight
    public void updateDailyWeight(String oldDate, String newDate, String newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, newDate);
        values.put(COLUMN_WEIGHT, newWeight);

        // update the record with the old date
        db.update(TABLE_DAILY_WEIGHT, values, COLUMN_DATE + " = ?", new String[]{oldDate});
        db.close();
    }

    // set goal weight
    public void setGoalWeight(String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("DELETE FROM " + TABLE_GOAL_WEIGHT);

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        db.insert(TABLE_GOAL_WEIGHT, null, values);
        db.close();
    }

    // get goal weight
    public String getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT goal FROM goal_weight LIMIT 1", null);

        if (cursor != null && cursor.moveToFirst()) {
            String goalWeight = cursor.getString(cursor.getColumnIndex(COLUMN_GOAL_WEIGHT));
            cursor.close();
            return goalWeight;
        }
        cursor.close();
        return "0"; // return default value if no goal weight is found
    }

    // delete a daily weight
    public void deleteDailyWeight(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_DAILY_WEIGHT, COLUMN_DATE + " = ?", new String[]{date});
        db.close();
    }

    // get most recent weight entered
    public String getMostRecentWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT weight FROM daily_weights ORDER BY date DESC LIMIT 1", null);

        if (cursor != null && cursor.moveToFirst()) {
            String weight = cursor.getString(cursor.getColumnIndex(COLUMN_WEIGHT));
            cursor.close();
            return weight;
        }
        cursor.close();
        return "0"; // return default value if no weight is found
    }

    // get first weight entered
    public String getFirstWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT weight FROM daily_weights ORDER BY date ASC LIMIT 1", null);

        if (cursor != null && cursor.moveToFirst()) {
            String firstWeight = cursor.getString(cursor.getColumnIndex(COLUMN_WEIGHT));
            cursor.close();
            return firstWeight;
        }
        cursor.close();
        return "0"; // return default value if no weight is found
    }

    // retrieve all daily weights from database and add them to RecyclerView
    public List<Weight> getAllWeights() {
        List<Weight> weightList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_DAILY_WEIGHT + " ORDER BY " + COLUMN_DATE + " DESC", null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
                String weight = cursor.getString(cursor.getColumnIndex(COLUMN_WEIGHT));
                weightList.add(new Weight(date, weight));
            }
            cursor.close();
        }

        db.close();
        return weightList;
    }

    // retrieve a weight by its date
    public Weight getWeightByDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_DAILY_WEIGHT, null, "date = ?", new String[]{date}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String weight = cursor.getString(cursor.getColumnIndex(COLUMN_WEIGHT));
            cursor.close();
            return new Weight(date, weight);  // return the existing weight
        }

        return null;  // return null if no weight for the date exists
    }
}
