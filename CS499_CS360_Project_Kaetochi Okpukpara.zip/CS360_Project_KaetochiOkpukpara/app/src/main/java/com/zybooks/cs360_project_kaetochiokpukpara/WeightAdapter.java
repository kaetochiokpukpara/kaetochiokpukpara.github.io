package com.zybooks.cs360_project_kaetochiokpukpara;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    public interface OnWeightDeletedListener {
        void onWeightDeleted();
    }

    private Context context;
    private List<Weight> weightList;
    private DatabaseHelper dbHelper;
    private OnWeightDeletedListener weightDeletedListener;

    // constructor
    public WeightAdapter(Context context, List<Weight> weightList, DatabaseHelper dbHelper, OnWeightDeletedListener weightDeletedListener) {
        this.context = context;
        this.weightList = weightList;
        this.dbHelper = dbHelper;
        this.weightDeletedListener = weightDeletedListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.grid_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Weight weight = weightList.get(position);

        holder.dateTextView.setText(weight.getDate());
        holder.weightTextView.setText(weight.getWeight());

        // show edit button
        holder.buttonEdit.setVisibility(View.VISIBLE);

        holder.buttonEdit.setOnClickListener(v -> {
            if (context instanceof WeightTrackerActivity) {
                ((WeightTrackerActivity) context).showEditPopup(weight.getDate(), weight.getWeight());
            }
        });

        // show delete button
        holder.buttonDelete.setVisibility(View.VISIBLE);

        holder.buttonDelete.setOnClickListener(v -> {
            // remove the weight from the database
            dbHelper.deleteDailyWeight(weight.getDate());

            // remove the weight from the grid
            weightList.remove(position);

            // notify the adapter to refresh the grid
            notifyItemRemoved(position);

            // notify activity to refresh current and starting weight
            if (weightDeletedListener != null) {
                weightDeletedListener.onWeightDeleted();
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        ImageButton buttonEdit;
        ImageButton buttonDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.textDate);
            weightTextView = itemView.findViewById(R.id.textWeight);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
