package com.zybooks.cs360_project_kaetochiokpukpara;

// class to represent meal entries
public class Meal {
    private int id;
    private String name;
    private int calories;
    private String date;

    // constructor with id
    public Meal(int id, String name, int calories, String date) {
        this.id = id;
        this.name = name;
        this.calories = calories;
        this.date = date;
    }

    // constructor without id
    public Meal(String name, int calories, String date) {
        this.id = 0;
        this.name = name;
        this.calories = calories;
        this.date = date;
    }

    // getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCalories() {
        return calories;
    }

    public String getDate() {
        return date;
    }

    // setters
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
