package com.zybooks.cs360_project_kaetochiokpukpara;

import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.telephony.SmsManager;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class WeightTrackerActivity extends AppCompatActivity implements WeightAdapter.OnWeightDeletedListener {

    private static final String PHONE_NUM = "5556";
    private RecyclerView recyclerView;
    private WeightAdapter weightAdapter;
    private List<Weight> weightList;
    private TextView textCurrentWeight, textGoalWeight, textStartingWeight, textDailyCalories;
    private RecyclerView mealRecyclerView;
    private MealAdapter mealAdapter;
    private List<Meal> mealList;
    private ImageButton buttonNotifications;
    private FloatingActionButton fabMain, fabDailyWeight, fabGoalWeight, fabAddMeal;
    private View blurBackground;
    private boolean isFabOpen = false;
    private DatabaseHelper dbHelper;
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        dbHelper = new DatabaseHelper(this);

        // fetch daily weights from the database
        weightList = dbHelper.getAllWeights();

        // set up RecyclerView
        recyclerView = findViewById(R.id.recyclerViewWeights);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightAdapter = new WeightAdapter(this, weightList, dbHelper, (WeightAdapter.OnWeightDeletedListener) this);
        recyclerView.setAdapter(weightAdapter);

        mealRecyclerView = findViewById(R.id.mealRecyclerView);

        mealList = dbHelper.getAllMeals();
        if (mealList == null) {
            mealList = new ArrayList<>();
        }
        mealAdapter = new MealAdapter(this, mealList, new MealAdapter.OnMealChangedListener() {
            @Override
            public void onMealDeleted() {
                updateDailyCalories();
            }
        });
        updateDailyCalories();

        // use GridLayoutManager for grid style (2 columns)
        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        mealRecyclerView.setLayoutManager(layoutManager);
        mealRecyclerView.setAdapter(mealAdapter);

        textCurrentWeight = findViewById(R.id.textCurrentWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        textStartingWeight = findViewById(R.id.textStartingWeight);
        textDailyCalories = findViewById(R.id.textDailyCalories);

        // get the most recent weight, goal weight, and first weight
        String currentWeight = dbHelper.getMostRecentWeight();
        String goalWeight = dbHelper.getGoalWeight();
        String startingWeight = dbHelper.getFirstWeight();

        // set the values in the respective TextViews
        textCurrentWeight.setText(String.format("%s lbs", currentWeight));
        textGoalWeight.setText(String.format("%s lbs", goalWeight));
        textStartingWeight.setText(String.format("%s lbs", startingWeight));

        fabMain = findViewById(R.id.fab);
        fabDailyWeight = findViewById(R.id.fabAddDailyWeight);
        fabGoalWeight = findViewById(R.id.fabAddGoalWeight);
        fabAddMeal = findViewById(R.id.fabAddMeal);
        blurBackground = findViewById(R.id.blurBackground);

        fabMain.setOnClickListener(view -> toggleFabMenu());
        fabDailyWeight.setOnClickListener(v -> {
            toggleFabMenu();
            showDailyWeightPopup();
        });
        fabGoalWeight.setOnClickListener(v -> {
            toggleFabMenu();
            showGoalWeightPopup();
        });
        fabAddMeal.setOnClickListener(v -> {
            toggleFabMenu();
            showAddMealPopup();
        });
        blurBackground.setOnClickListener(v -> toggleFabMenu());

        buttonNotifications = findViewById(R.id.buttonNotifications);

        // check for SMS permission when button is pressed
        buttonNotifications.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // if permission is not granted, request it
                ActivityCompat.requestPermissions(WeightTrackerActivity.this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            } else {
                // if permission is already granted, show message
                Toast.makeText(WeightTrackerActivity.this, "Notifications on.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // permission granted
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                // permission denied
                Toast.makeText(this, "Permission denied. Notification functionality will be limited.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onWeightDeleted() {
        // update current and starting weight after a weight is deleted
        String currentWeight = dbHelper.getMostRecentWeight();
        String startingWeight = dbHelper.getFirstWeight();

        textCurrentWeight.setText(String.format("%s lbs", currentWeight));
        textStartingWeight.setText(String.format("%s lbs", startingWeight));
    }

    private void toggleFabMenu() {
        if (isFabOpen) {
            fabDailyWeight.setVisibility(View.GONE);
            fabGoalWeight.setVisibility(View.GONE);
            fabAddMeal.setVisibility(View.GONE);
            blurBackground.setVisibility(View.GONE);
            isFabOpen = false;
        } else {
            fabDailyWeight.setVisibility(View.VISIBLE);
            fabGoalWeight.setVisibility(View.VISIBLE);
            fabAddMeal.setVisibility(View.VISIBLE);
            blurBackground.setVisibility(View.VISIBLE);
            isFabOpen = true;
        }
    }

    private void showDailyWeightPopup() {
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_add_daily_weight, null);
        PopupWindow popupWindow = new PopupWindow(popupView, RecyclerView.LayoutParams.WRAP_CONTENT, RecyclerView.LayoutParams.WRAP_CONTENT, true);
        popupWindow.showAtLocation(recyclerView, android.view.Gravity.CENTER, 0, 0);
        blurBackground.setVisibility(View.VISIBLE);

        EditText editTextDate = popupView.findViewById(R.id.editTextDate);
        EditText editTextWeight = popupView.findViewById(R.id.editTextWeight);
        ImageButton buttonSave = popupView.findViewById(R.id.buttonSaveDailyWeight);
        ImageButton buttonCancel = popupView.findViewById(R.id.buttonCancelDaily);

        buttonSave.setOnClickListener(v -> {
            String date = editTextDate.getText().toString();
            String weight = editTextWeight.getText().toString();
            if (!date.isEmpty() && !weight.isEmpty()) {
                // check if the weight for the given date already exists in the database
                Weight existingWeight = dbHelper.getWeightByDate(date);

                if (existingWeight != null) {
                    // if it exists, update existing weight in database
                    dbHelper.updateDailyWeight(existingWeight.getDate(), date, weight);

                    // update the weight in the list
                    for (Weight weightItem : weightList) {
                        if (weightItem.getDate().equals(date)) {
                            weightItem.setWeight(weight);
                            break;
                        }
                    }
                } else {
                    dbHelper.addDailyWeight(date, weight);
                    weightList.add(new Weight(date, weight));
                }

                weightAdapter.notifyDataSetChanged();

                String currentWeight = dbHelper.getMostRecentWeight();
                String startingWeight = dbHelper.getFirstWeight();
                textCurrentWeight.setText(String.format("%s lbs", currentWeight));
                textStartingWeight.setText(String.format("%s lbs", startingWeight));

                checkGoalWeightReached();
                popupWindow.dismiss();
            }
            blurBackground.setVisibility(View.GONE);
        });

        buttonCancel.setOnClickListener(v -> {
            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });
    }

    private void showGoalWeightPopup() {
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_add_goal_weight, null);
        PopupWindow popupWindow = new PopupWindow(popupView, RecyclerView.LayoutParams.WRAP_CONTENT, RecyclerView.LayoutParams.WRAP_CONTENT, true);
        popupWindow.showAtLocation(recyclerView, android.view.Gravity.CENTER, 0, 0);
        blurBackground.setVisibility(View.VISIBLE);

        EditText editTextGoalWeight = popupView.findViewById(R.id.editTextGoalWeight);
        ImageButton buttonSave = popupView.findViewById(R.id.buttonSaveGoalWeight);
        ImageButton buttonCancel = popupView.findViewById(R.id.buttonCancelGoal);

        buttonSave.setOnClickListener(v -> {
            String goalWeight = editTextGoalWeight.getText().toString();
            if (!goalWeight.isEmpty()) {
                dbHelper.setGoalWeight(goalWeight);
                textGoalWeight.setText(String.format("%s lbs", goalWeight));
                checkGoalWeightReached();
                popupWindow.dismiss();
            }
            blurBackground.setVisibility(View.GONE);
        });

        buttonCancel.setOnClickListener(v -> {
            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });
    }

    public void showEditPopup(String date, String weight) {
        View popupView = getLayoutInflater().inflate(R.layout.popup_edit_daily_weight, null);

        EditText editTextDate = popupView.findViewById(R.id.editTextDate);
        EditText editTextWeight = popupView.findViewById(R.id.editTextWeight);
        ImageButton buttonSave = popupView.findViewById(R.id.buttonSaveEdit);
        ImageButton buttonCancel = popupView.findViewById(R.id.buttonCancelEdit);

        editTextDate.setText(date);
        editTextWeight.setText(weight);

        PopupWindow popupWindow = new PopupWindow(popupView, RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT, true);
        popupWindow.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        blurBackground.setVisibility(View.VISIBLE);

        buttonSave.setOnClickListener(v -> {
            String updatedDate = editTextDate.getText().toString();
            String updatedWeight = editTextWeight.getText().toString();

            dbHelper.updateDailyWeight(date, updatedDate, updatedWeight);

            // update grid
            for (Weight weightItem : weightList) {
                if (weightItem.getDate().equals(date)) {
                    weightItem.setDate(updatedDate);
                    weightItem.setWeight(updatedWeight);
                    break;
                }
            }

            weightAdapter.notifyDataSetChanged();

            // update current and starting weight
            String currentWeight = dbHelper.getMostRecentWeight();
            String startingWeight = dbHelper.getFirstWeight();
            textCurrentWeight.setText(String.format("%s lbs", currentWeight));
            textStartingWeight.setText(String.format("%s lbs", startingWeight));

            checkGoalWeightReached();

            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });

        buttonCancel.setOnClickListener(v -> {
            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });
    }

    private void showAddMealPopup() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View popupView = inflater.inflate(R.layout.popup_add_meal, null);

        EditText editMealName = popupView.findViewById(R.id.editTextMealName);
        EditText editCalories = popupView.findViewById(R.id.editTextCalories);
        EditText editDate = popupView.findViewById(R.id.editTextMealDate);
        ImageButton buttonSave = popupView.findViewById(R.id.buttonSaveMeal);
        ImageButton buttonCancel = popupView.findViewById(R.id.buttonCancelMeal);

        if (mealList == null) {
            mealList = dbHelper.getAllMeals();
        }
        PopupWindow popupWindow = new PopupWindow(popupView, RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT, true);
        popupWindow.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        blurBackground.setVisibility(View.VISIBLE);

        buttonSave.setOnClickListener(v -> {
            String name = editMealName.getText().toString().trim();
            String caloriesStr = editCalories.getText().toString().trim();
            String date = editDate.getText().toString().trim();

            if (!name.isEmpty() && !caloriesStr.isEmpty() && !date.isEmpty()) {
                int calories = Integer.parseInt(caloriesStr);
                long id = dbHelper.addMeal(name, calories, date);
                Meal meal = new Meal((int) id, name, calories, date);
                mealList.add(meal);
                mealAdapter.notifyItemInserted(mealList.size() - 1);
                popupWindow.dismiss();
                blurBackground.setVisibility(View.GONE);
                updateDailyCalories();
            } else {
                Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonCancel.setOnClickListener(v -> {
            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });
    }

    public void showEditMealPopup(Meal meal, int position) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.popup_edit_meal, null);

        PopupWindow popupWindow = new PopupWindow(popupView, RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT, true);
        popupWindow.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        blurBackground.setVisibility(View.VISIBLE);

        EditText editTextName = popupView.findViewById(R.id.editTextEditMealName);
        EditText editTextCalories = popupView.findViewById(R.id.editTextEditMealCalories);
        EditText editTextDate = popupView.findViewById(R.id.editTextEditMealDate);
        ImageButton buttonSave = popupView.findViewById(R.id.buttonSaveMealEdit);
        ImageButton buttonCancel = popupView.findViewById(R.id.buttonCancelEditMeal);

        editTextName.setText(meal.getName());
        editTextCalories.setText(String.valueOf(meal.getCalories()));
        editTextDate.setText(meal.getDate());

        buttonSave.setOnClickListener(v -> {
            String newName = editTextName.getText().toString();
            String newCaloriesStr = editTextCalories.getText().toString();
            String newDate = editTextDate.getText().toString();

            if (!newName.isEmpty() && !newCaloriesStr.isEmpty() && !newDate.isEmpty()) {
                int newCalories = Integer.parseInt(newCaloriesStr);

                dbHelper.updateMeal(meal.getId(), newName, newCalories, newDate);

                meal.setName(newName);
                meal.setCalories(newCalories);
                meal.setDate(newDate);

                mealList.set(position, meal);
                mealAdapter.notifyItemChanged(position);

                popupWindow.dismiss();
                blurBackground.setVisibility(View.GONE);
                updateDailyCalories();
            } else {
                Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonCancel.setOnClickListener(v -> {
            popupWindow.dismiss();
            blurBackground.setVisibility(View.GONE);
        });
    }

    private void checkGoalWeightReached() {
        String currentWeight = dbHelper.getMostRecentWeight();
        String goalWeight = dbHelper.getGoalWeight();

        if (!currentWeight.isEmpty() && !goalWeight.isEmpty()) {
            try {
                float current = Float.parseFloat(currentWeight);
                float goal = Float.parseFloat(goalWeight);
                if (current <= goal) {
                    sendGoalReachedSMS();
                    Toast.makeText(this, "Goal weight reached!", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendGoalReachedSMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(PHONE_NUM, null,
                    "Congratulations! You have reached your goal weight!",
                    null, null);
        }
    }

    private void updateDailyCalories() {
        textDailyCalories = findViewById(R.id.textDailyCalories);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        List<Meal> allMeals = dbHelper.getAllMeals();

        if (allMeals == null || allMeals.isEmpty()) {
            textDailyCalories.setText("0 cal");
            return;
        }

        int totalCalories = 0;
        for (Meal meal : allMeals) {
            if (meal.getDate().equals(today)) {
                totalCalories += meal.getCalories();
            }
        }

        textDailyCalories.setText(totalCalories + " cal");
    }
}