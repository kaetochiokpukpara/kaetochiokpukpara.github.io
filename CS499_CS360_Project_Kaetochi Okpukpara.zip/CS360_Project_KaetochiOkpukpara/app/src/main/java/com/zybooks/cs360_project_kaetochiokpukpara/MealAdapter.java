package com.zybooks.cs360_project_kaetochiokpukpara;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MealAdapter extends RecyclerView.Adapter<MealAdapter.MealViewHolder> {
    public interface OnMealChangedListener {
        void onMealDeleted();
    }

    private DatabaseHelper dbHelper;
    private List<Meal> mealList;
    private Context context;
    private OnMealChangedListener mealChangedListener;

    // constructor
    public MealAdapter(Context context, List<Meal> mealList, OnMealChangedListener listener) {
        this.context = context;
        this.mealList = mealList;
        this.dbHelper = new DatabaseHelper(context);
        this.mealChangedListener = listener;
    }

    public static class MealViewHolder extends RecyclerView.ViewHolder {
        TextView textViewMealName, textViewCalories, textViewMealDate;
        ImageButton buttonEditMeal, buttonDeleteMeal;

        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewMealName = itemView.findViewById(R.id.textViewMealName);
            textViewCalories = itemView.findViewById(R.id.textViewMealCalories);
            textViewMealDate = itemView.findViewById(R.id.textViewMealDate);
            buttonEditMeal = itemView.findViewById(R.id.buttonEditMeal);
            buttonDeleteMeal = itemView.findViewById(R.id.buttonDeleteMeal);
        }
    }

    @NonNull
    @Override
    public MealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item_meal, parent, false);
        return new MealViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MealViewHolder holder, int position) {
        Meal meal = mealList.get(position);
        holder.textViewMealName.setText(meal.getName());
        holder.textViewCalories.setText(meal.getCalories() + " cal");
        holder.textViewMealDate.setText(meal.getDate());

        // handle edit
        holder.buttonEditMeal.setVisibility(View.VISIBLE);

        holder.buttonEditMeal.setOnClickListener(v -> {
            if (context instanceof WeightTrackerActivity) {
                ((WeightTrackerActivity) context).showEditMealPopup(meal, position);
            }
        });

        // handle delete
        holder.buttonDeleteMeal.setOnClickListener(v -> {
            dbHelper.deleteMeal(meal.getId());
            mealList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, mealList.size());

            if (mealChangedListener != null) {
                mealChangedListener.onMealDeleted();
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mealList != null) ? mealList.size() : 0;
    }
}
